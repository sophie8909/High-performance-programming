#define G 66

void print_pyramid(int pyramidSize);
