echo Hej hej
echo Hej då